<?php
/**
 * Single Services Page
 * *
 */
get_header();

global $startnext_opt;
if( isset( $startnext_opt['enable_lazyloader'] ) ):
    $is_lazyloader = $startnext_opt['enable_lazyloader'];
else:
    $is_lazyloader = true;
endif;

$is_shape_image     = isset( $startnext_opt['enable_shape_images']) ? $startnext_opt['enable_shape_images'] : '1';
$bg_image           = isset( $startnext_opt['banner_shape_image']['url']) ? $startnext_opt['banner_shape_image']['url'] : '';
$background_image = !empty( $bg_image ) ? "style='background: url( $bg_image );'" : '';

?>
    <div class="page-title-area" <?php echo $background_image; ?>>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <h2><?php the_title(); ?></h2>
                    <?php if ( function_exists('yoast_breadcrumb') ) {
                        yoast_breadcrumb( '<p class="startnext-seo-breadcrumbs" id="breadcrumbs">','</p>' );
                    } ?>
                </div>
            </div>
        </div>
        
        <?php if( $is_shape_image == '1' ): ?>
            <div class="shape1">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
            <div class="shape2 rotateme">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
            <div class="shape3">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
            <div class="shape4">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
            <div class="shape5">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
            <div class="shape6 rotateme">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                <?php endif; ?>
            </div>
            <div class="shape7">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
            <div class="shape8 rotateme">
                <?php if( $is_lazyloader == true ): ?>
                    <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Start features Details Area -->
    <section class="features-details-area ptb-80">
        <div class="container">
            <?php 
            while ( have_posts() ) :
                the_post(); 
                    $service_faq_content    =   get_field('service_faq_content');
                    $service_faq_image      =   get_field('service_faq_image');
                    $service_faqs           =   get_field('service_faq');
                
                ?>
                <div class="row align-items-center">
                    <div class="features-details">
                        <div class="features-details-desc">
                            <?php the_content();?>
                        </div>
                    </div>
                </div>

                <div class="separate"></div>

                <div class="row align-items-center">
                    <div class="col-lg-6 features-details-image">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify wow fadeInUp" sm-src="<?php echo esc_url( $service_faq_image['url'] ); ?>" alt="<?php echo esc_attr( $service_faq_image['alt'] ); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url( $service_faq_image['url'] ); ?>" class="wow fadeInUp" alt="<?php echo esc_attr( $service_faq_image['alt'] ); ?>">
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-6 features-details">
                        <div class="features-details-desc">
                            <p><?php echo esc_html( $service_faq_content ); ?></p>
                            <?php if(!$service_faqs == '' ){ ?>
                                <div class="features-details-accordion">
                                    <ul class="accordion">
                                        <?php 
                                        $i = 0;
                                        foreach ( $service_faqs as $item ) {
                                            if($i == 0){ ?>
                                            <li class="accordion-item">
                                                <a class="accordion-title active" href="javascript:void(0)">
                                                    <i class="fas fa-plus"></i>
                                                    <?php echo esc_html($item['services_faq_title']); ?>
                                                </a>

                                                <p class="accordion-content show"><?php echo esc_html($item['services_faq_description']); ?></p>
                                            </li>
                                            <?php }else{ ?>
                                                <li class="accordion-item">
                                                    <a class="accordion-title" href="javascript:void(0)">
                                                        <i class="fas fa-plus"></i>
                                                        <?php echo esc_html($item['services_faq_title']); ?>
                                                    </a>

                                                    <p class="accordion-content"><?php echo esc_html($item['services_faq_description']); ?></p>
                                                </li>
                                            <?php } $i++; 
                                        } ?>
                                    </ul>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
    <!-- End Services Details Area -->

<?php
get_footer();
