<?php
/**
 * Post Format: Audio
 * @package StartNext
 */

global $startnext_opt;
if( isset($startnext_opt['post_read_more']) ):
    $readmore     = $startnext_opt['post_read_more'];
    $columns      = $startnext_opt['blog_columns'];
else:
    $readmore     = 'Read More';
    $columns      = '2';
endif;

if($columns == 1) {
    $grid = "col-xl-12 grid-item";
    $thumb_size = "startnext_post_one_columns_card_thumb";
}elseif($columns == 2) {
    $grid = "col-xl-6 grid-item";
    $thumb_size = "startnext_post_card_thumb";

}else {
    $grid = "col-xl-6 grid-item";
    $thumb_size = "startnext_post_card_thumb";
}
if($columns == '1') {
    $grid = "col-xl-12 grid-item";
    $thumb_size = "startnext_post_one_columns_card_thumb";
}elseif($columns == '2') {
    $grid = "col-xl-6 grid-item";
    $thumb_size = "startnext_post_card_thumb";

}else {
    $grid = "col-xl-6 grid-item";
    $thumb_size = "startnext_post_card_thumb";
}

if(isset($startnext_opt['startnext_blog_sidebar'])) {
    if( $startnext_opt['startnext_blog_sidebar'] == 'startnext_without_sidebar_center' ):
        $sidebar = 'col-lg-8 col-md-12 offset-lg-2';
    elseif( $startnext_opt['startnext_blog_sidebar'] == 'startnext_without_sidebar' ):
        $sidebar = 'col-lg-12 col-md-12';
    else:
        if( is_active_sidebar( 'sidebar-1' ) ):
            $sidebar = 'col-lg-8 col-md-12';
        else:
            $sidebar = 'col-lg-8 col-md-12 offset-lg-2';
        endif;
    endif;
    $startnext_sidebar_hide = $startnext_opt['startnext_blog_sidebar'];
} else {
    if( is_active_sidebar( 'sidebar-1' ) ):
        $sidebar = 'col-lg-8 col-md-12';
        $startnext_sidebar_hide = 'startnext_with_sidebar';
    else:
        $sidebar = 'col-lg-8 col-md-12 offset-lg-2';
        $startnext_sidebar_hide = 'startnext_without_sidebar';
    endif;
}

if ( !empty($_GET['startnext_sidebar_hide']) ) {
    $startnext_sidebar_hide = $_GET['startnext_sidebar_hide'];
}

if ( !empty($_GET['startnext_blog_sidebar']) ) {
    $sidebar = $_GET['startnext_blog_sidebar'];
}

$startnext_blog_layout = !empty($startnext_opt['startnext_blog_layout']) ? $startnext_opt['startnext_blog_layout'] : 'container';
if ( !empty($_GET['startnext_blog_layout']) ) {
    $startnext_blog_layout = $_GET['startnext_blog_layout'];
}
?>

<div class="<?php if ( $startnext_sidebar_hide == 'startnext_with_sidebar' ) { echo esc_attr($grid, 'startnext');} else{ echo esc_attr('col-xl-4 grid-item');} ?>">
    <div  <?php post_class( 'single-blog-post' ); ?> >
        <?php if ( has_post_thumbnail() ) { ?>
        <div class="blog-image">
            <a href="<?php the_permalink() ?>">
                 <?php the_post_thumbnail($thumb_size) ?>
            </a>
        </div>
        <?php } ?>

        <div class="blog-post-content <?php if ( !has_post_thumbnail() ) {echo esc_attr('without-thumb');} ?>">
            <div class="post_type_icon">
                <i class="fa fa-volume-up"></i>
            </div>

            <h3><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3>
            <?php if( isset( $startnext_opt['is_post_meta'] ) && $startnext_opt['is_post_meta'] == true ) { ?>
                <ul> 
                    <li>
                        <i class="fa fa-user"></i>
                        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ) ?>">
                            <?php the_author() ?>
                        </a> 
                    </li>
                    <li>
                        <i class="fa fa-calendar"></i>
                        <?php echo wp_kses_post(get_the_date('F d, Y')) ?>
                    </li>
                </ul>
            <?php } ?>
            <?php the_excerpt() ?>

            <?php if(!$readmore == ''){ ?>
                <div class="mt-2">
                    <a href="<?php the_permalink() ?>" class="read-more-btn">
                        <?php echo  esc_html($readmore, 'startnext') ?> 
                        <i data-feather="arrow-right"></i> 
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</div>