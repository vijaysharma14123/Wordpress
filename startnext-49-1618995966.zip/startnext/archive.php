<?php
/**
 * StartNext archive pages
 *
 * @package StartNext
 */

get_header();

global $startnext_opt;
if( isset( $startnext_opt['enable_lazyloader'] ) ):
    $is_lazyloader = $startnext_opt['enable_lazyloader'];
else:
    $is_lazyloader = true;
endif;

$is_shape_image     = isset( $startnext_opt['enable_shape_images']) ? $startnext_opt['enable_shape_images'] : '1';
$bg_image           = isset( $startnext_opt['banner_shape_image']['url']) ? $startnext_opt['banner_shape_image']['url'] : '';
$background_image = !empty( $bg_image ) ? "style='background: url( $bg_image );'" : '';

if(isset($startnext_opt['startnext_blog_sidebar'])) {
    if( $startnext_opt['startnext_blog_sidebar'] == 'startnext_without_sidebar_center' ):
        $sidebar = 'col-lg-8 col-md-12 offset-lg-2';
    elseif( $startnext_opt['startnext_blog_sidebar'] == 'startnext_without_sidebar' ):
        $sidebar = 'col-lg-12 col-md-12';
    else:
        if( is_active_sidebar( 'sidebar-1' ) ):
            $sidebar = 'col-lg-8 col-md-12';
        else:
            $sidebar = 'col-lg-8 col-md-12 offset-lg-2';
        endif;
    endif;
    $startnext_sidebar_hide = $startnext_opt['startnext_blog_sidebar'];
} else {
    if( is_active_sidebar( 'sidebar-1' ) ):
        $sidebar = 'col-lg-8 col-md-12';
        $startnext_sidebar_hide = 'startnext_with_sidebar';
    else:
        $sidebar = 'col-lg-8 col-md-12 offset-lg-2';
        $startnext_sidebar_hide = 'startnext_without_sidebar';
    endif;
}

if ( !empty($_GET['startnext_sidebar_hide']) ) {
    $startnext_sidebar_hide = $_GET['startnext_sidebar_hide'];
}

if ( !empty($_GET['startnext_blog_sidebar']) ) {
    $sidebar = $_GET['startnext_blog_sidebar'];
}

$startnext_blog_layout = !empty($startnext_opt['startnext_blog_layout']) ? $startnext_opt['startnext_blog_layout'] : 'container';
if ( !empty($_GET['startnext_blog_layout']) ) {
    $startnext_blog_layout = $_GET['startnext_blog_layout'];
}
?>

    <?php $page = get_post_meta(get_the_ID(),"_startnext_home_page_",true);
    if ((!$page) OR (!is_front_page() && !is_home())) : ?>
        <div class="page-title-area" <?php echo $background_image; ?>>
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <h2><?php the_archive_title(); ?></h2>
                        <?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>
                        <?php if ( function_exists('yoast_breadcrumb') ) {
							yoast_breadcrumb( '<p class="startnext-seo-breadcrumbs" id="breadcrumbs">','</p>' );
						} ?>
                    </div>
                </div>
            </div>
            
            <?php if( $is_shape_image == '1' ): ?>
                <div class="shape1">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape2 rotateme">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape3">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape4">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape5">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape6 rotateme">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                    <?php endif; ?>
                </div>
                <div class="shape7">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape8 rotateme">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <section class="blog-area ptb-80">
        <div class="<?php echo esc_attr( $startnext_blog_layout ); ?>">
            <div class="row">
                <div class="<?php echo esc_attr( $sidebar ); ?>">
                    <?php
                    if ( have_posts() ) : ?>
                        <div class="row grid">
                        <?php
                        while ( have_posts() ) :the_post(); 
                            get_template_part( 'template-parts/post-formats/content',get_post_format());
                        endwhile;
                        ?>
                        </div>
                        
                        <div class="col-lg-12 col-md-12">
                            <div class="pagination-area">
                                <nav aria-label="Page navigation">
                                <?php 
                                    $pagination =  paginate_links( array(
                                        'format' => '?paged=%#%',
                                        'prev_text' => '<i class="fa fa-chevron-left"></i>',
                                        'next_text' => '<i class="fa fa-chevron-right"></i>',
                                        )
                                ) ;
                                echo wp_kses_post($pagination, 'startnext');
                                ?>
                                </nav>
                            </div>
                        </div>
                        <?php
                    else :
                        get_template_part( 'template-parts/content', 'none' );
                    endif;
                    ?>
                </div>
                <?php if( $startnext_sidebar_hide == 'startnext_with_sidebar' ): ?>
                    <?php get_sidebar(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

<?php
get_sidebar();
get_footer();
