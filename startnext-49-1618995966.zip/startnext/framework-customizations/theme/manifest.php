<?php

if ( !defined( 'FW' ) ) {
	wp_die(  'Forbidden' );
}

$manifest = array();

$manifest[ 'name' ]			 = esc_html__( 'StartNext', 'startnext' );
$manifest[ 'uri' ]			 = esc_url( 'https://themes.envytheme.com/startp/' );
$manifest[ 'description' ]	 = esc_html__( 'Elementor IT & Business Startups WP Theme', 'startnext' );
$manifest[ 'version' ]		 = '4.3';
$manifest[ 'author' ]		 = 'EnvyTheme';
$manifest[ 'author_uri' ]	 = esc_url( 'https://themes.envytheme.com/startp/' );
$manifest[ 'requirements' ]	 = array(
	'wordpress' => array(
		'min_version' => '4.3',
	),
);

$manifest[ 'id' ] = 'scratch';

$manifest[ 'supported_extensions' ] = array(
	'backups'		 => array(),
);

?>
