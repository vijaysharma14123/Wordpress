<?php
/**
 * The template for displaying all pages
*/
get_header();

$vc_enabled = get_post_meta(get_the_ID(), '_wpb_vc_js_status', true);

if( function_exists('acf_add_options_page') ) {
	$hide_banner = get_field('page_banner_hide');
}else {
	$hide_banner = false;
}

$is_shape_image     = isset( $startnext_opt['enable_shape_images']) ? $startnext_opt['enable_shape_images'] : '1';
$bg_image           = isset( $startnext_opt['banner_shape_image']['url']) ? $startnext_opt['banner_shape_image']['url'] : '';
$background_image = !empty( $bg_image ) ? "style='background: url( $bg_image );'" : '';

global $startnext_opt;
if( isset( $startnext_opt['enable_lazyloader'] ) ):
    $is_lazyloader = $startnext_opt['enable_lazyloader'];
else:
    $is_lazyloader = true;
endif;

?>
    <?php if( $hide_banner == false ): ?>
        <div class="page-title-area" <?php echo $background_image; ?>>
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
						<h2><?php the_title(); ?></h2>
						<?php if ( function_exists('yoast_breadcrumb') ) {
							yoast_breadcrumb( '<p class="startnext-seo-breadcrumbs" id="breadcrumbs">','</p>' );
						} ?>
                    </div>
                </div>
			</div>
			
            <?php if( $is_shape_image == '1' ): ?>
                <div class="shape1">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape2 rotateme">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>

                <div class="shape3">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape4">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape5">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape6 rotateme">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                    <?php endif; ?>
                </div>
                <div class="shape7">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
                <div class="shape8 rotateme">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
	<?php endif; ?>

	<?php if ($vc_enabled !== 'true' && !startnext_is_elementor() ) {  ?>
	<div class="main-content">
	<?php } ?>

		<?php if( !startnext_is_elementor()): ?>
			<div id="primary" class="container">
		<?php endif; ?>
			<?php
			while ( have_posts() ) :
				the_post();
                $thecontent = get_the_content();
                if (class_exists( 'WooCommerce' ) && is_shop()) {
                    get_template_part( 'template-parts/content', 'page' );
                }else {
                    if(empty($thecontent)){  ?><div class="single-blank-page"> </div><?php }

                    get_template_part( 'template-parts/content', 'page' );
                }
				
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; 
			?>
		<?php if( !startnext_is_elementor()): ?>
			</div>
		<?php endif; ?>
	<?php 
	if ($vc_enabled !== 'true' && !startnext_is_elementor() ) {  ?>
	</div>
	<?php } ?>
<?php
get_footer();
