<?php
 /**
 * StartNext functions and definitions
 * @package WordPress
 * @subpackage StartNext
 */
 
if( !defined('STARTNEXT_FRAMEWORK_VAR') ) define('STARTNEXT_FRAMEWORK_VAR', 'startnext_opt');

if ( ! function_exists( 'startnext_setup' ) ) :
	function startnext_setup() {
		
		// Make theme available for translation.
		load_theme_textdomain( 'startnext', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );
        
        // Let WordPress manage the document title.
        add_theme_support( 'title-tag' );
        
        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support( 'post-thumbnails' );

        // Enable support for yoast seo plugin
		add_theme_support( 'yoast-seo-breadcrumbs' );

        // // Main Post Thumbnail Image Size
        add_image_size( 'startnext_post_card_thumb', 510, 300, true ); 

        // Blog Post Style=-2 Thumbnail Image Size
        add_image_size( 'startnext_ai_post_thumb', 510, 410, true ); 

        // Main Post Thumbnail Image Size One Columns
        add_image_size( 'startnext_post_one_columns_card_thumb', 730, 300, true ); 

        // Project Card Image Size
        add_image_size( 'startnext_project_card_thumb', 640, 450, true ); 

        // Project Slider Image Size
        add_image_size( 'startnext_project_slider_thumb', 500, 500, true ); 

        // Services Card Image Size
        add_image_size( 'startnext_service_card_thumb', 550, 450, true ); 

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'main-menu' => esc_html__( 'Main menu', 'startnext' ),
        ) );
        

		//Switch default core markup for search form, comment form, and comments to output valid HTML5.
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );
        
        // Add support for posts formats
        add_theme_support( 'post-formats', array( 'aside', 'gallery', 'link', 'image', 'quote', 'video', 'audio', 'chat') );
	}
endif;
add_action( 'after_setup_theme', 'startnext_setup' );

// Set the content width in pixels, based on the theme's design and stylesheet.
function startnext_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'startnext_content_width', 640 );
}
add_action( 'after_setup_theme', 'startnext_content_width', 0 );

//Register widget area.
function startnext_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'startnext' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'startnext' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
    ) );
    
    register_sidebar( array(
		'name'          => esc_html__( 'Shop', 'startnext' ),
		'id'            => 'shop-sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'startnext' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
    ) );
    
    global $startnext_opt;
    $footer_column = !empty($startnext_opt['footer_column']) ? $startnext_opt['footer_column'] : '';
    //Footer Widgets One
    register_sidebar( array(
        'name'          => esc_html__( 'Footer One', 'startnext' ),
        'id'            => 'footer-one',
        'description'   => esc_html__( 'Add widgets here.', 'startnext' ),
        'before_widget' => '<div>',
        'after_widget'  => '</div>'
    ) );

    //Footer Widgets Two
    register_sidebar( array(
		'name'          => esc_html__( 'Footer Two', 'startnext' ),
		'id'            => 'footer-two',
		'description'   => esc_html__( 'Add widgets here.', 'startnext' ),
		'before_widget' => '<div class="single-footer-widget col-lg-'.$footer_column.' col-md-'.$footer_column.'">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
    ) );

    //Footer Widgets Three
    register_sidebar( array(
		'name'          => esc_html__( 'Footer Three', 'startnext' ),
		'id'            => 'footer-three',
		'description'   => esc_html__( 'Add widgets here.', 'startnext' ),
		'before_widget' => '<div class="single-footer-widget col-lg-'.$footer_column.' col-md-'.$footer_column.'">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
    ) );

    //Footer Widgets Four
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Four', 'startnext' ),
        'id'            => 'footer-four',
        'description'   => esc_html__( 'Add widgets here.', 'startnext' ),
        'before_widget' => '<div>',
        'after_widget'  => '</div>'
    ) );
}
add_action( 'widgets_init', 'startnext_widgets_init' );

 // Enqueue scripts and styles.
function startnext_scripts() {
    global $startnext_opt;

    if( isset( $startnext_opt['enable_lazyloader'] ) ):
        $is_lazyloader = $startnext_opt['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    if( isset( $startnext_opt['enable_minify_css_js'] ) ):
        $is_minify = $startnext_opt['enable_minify_css_js'];
    else:
        $is_minify = true;
    endif;

    wp_enqueue_style( 'startnext-style', get_stylesheet_uri() );
    wp_style_add_data( 'startnext-style', 'rtl', 'replace' );

    wp_enqueue_style( 'vendors', get_template_directory_uri() . '/assets/css/vendors.min.css' );
    wp_enqueue_style( 'fontawesome-min', get_template_directory_uri() . '/assets/css/font-awesome.min.css' );
    wp_enqueue_style( 'fontawesome-all-min', get_template_directory_uri() . '/assets/css/all.min.css' );
    
    
    // Theme Style & Color
    if( function_exists('acf_add_options_page') ) {
        $page_color = get_field('page_color');
    }else {
        $page_color = '';
    }

    if ($page_color != '') {
        if ($page_color == 'pink' ) {
            if( $is_minify == true ):
                wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
            else :
                wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
            endif;
            wp_enqueue_style( 'startnext-pink-style-main', get_template_directory_uri() . '/assets/css/color/pink-style.css' );
        } elseif ($page_color == 'purple') {
            if( $is_minify == true ):
                wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
            else :
                wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
            endif;
            wp_enqueue_style( 'startnext-purple-style-main', get_template_directory_uri() . '/assets/css/color/purple-style.css' );
        } elseif ($page_color == 'brink-pink') {
            if( $is_minify == true ):
                wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
            else :
                wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
            endif;
            wp_enqueue_style( 'startnext-brink-pink-style-main', get_template_directory_uri() . '/assets/css/color/brink-pink-style.css' );
        } else {
            if( $is_minify == true ):
                wp_enqueue_style( 'startnext-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
            else :
                wp_enqueue_style( 'startnext-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
            endif;
        }
    }else{
        if ( isset( $startnext_opt['theme_color'] ) ) { 
            $theme_color =  $startnext_opt['theme_color'];
            if ($theme_color == 'pink_color' ) {
                wp_enqueue_style( 'startnext-pink-style-main', get_template_directory_uri() . '/assets/css/color/pink-style.css' );

                if( $is_minify == true ):
                    wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
                else :
                    wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
                endif;  
            }elseif ($theme_color == 'purple_color') {
                wp_enqueue_style( 'startnext-purple-style-main', get_template_directory_uri() . '/assets/css/color/purple-style.css' );
                if( $is_minify == true ):
                    wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
                else :
                    wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
                endif;
            }elseif ($theme_color == 'brink_pink_color') {
                wp_enqueue_style( 'startnext-brink-pink-style-main', get_template_directory_uri() . '/assets/css/color/brink-pink-style.css' );
                if( $is_minify == true ):
                    wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
                else :
                    wp_enqueue_style( 'startnext-color-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
                endif;
            }else{
                if( $is_minify == true ):
                    wp_enqueue_style( 'startnext-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
                else :
                    wp_enqueue_style( 'startnext-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
                endif;
            }
        }else{
            if( $is_minify == true ):
                wp_enqueue_style( 'startnext-style-main', get_template_directory_uri() . '/assets/css/startnext-style.min.css' );
            else :
                wp_enqueue_style( 'startnext-style-main', get_template_directory_uri() . '/assets/css/startnext-style.css' );
            endif;
        }  
    }

    if( $is_minify == true ):
        wp_enqueue_style( 'startnext-responsive', get_template_directory_uri() . '/assets/css/startnext-responsive.min.css' );
    else :
        wp_enqueue_style( 'startnext-responsive', get_template_directory_uri() . '/assets/css/startnext-responsive.css' );
    endif;

    // RTL CSS
    if( startnext_rtl() == true ):
        wp_enqueue_style( 'startnext-rtl', get_template_directory_uri() . '/style-rtl.css' );
    endif;

    wp_enqueue_script( 'vendors', get_template_directory_uri() . '/assets/js/vendors.min.js', array ( 'jquery' ), true);

    // Smartify JS 
    if( $is_lazyloader == true ):
        wp_enqueue_script( 'jquery-smartify', get_template_directory_uri() . '/assets/js/jquery.smartify.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'startnext-smartify', get_template_directory_uri() . '/assets/js/smartify.js', array( 'jquery' ), false, true );
    endif;

    // RTL CSS and JS
    if( isset( $startnext_opt['blog_title']) ):
        if( startnext_rtl() == true ):
            wp_enqueue_script( 'startnext-rtl', get_template_directory_uri() . '/assets/js/startnext-rtl.js', array( 'jquery','masonry' ), false, true );
        else:
            if( $is_minify == true ):
                wp_enqueue_script( 'startnext-main', get_template_directory_uri() . '/assets/js/startnext-main.min.js', array( 'jquery','masonry' ), false, true );
            else :
                wp_enqueue_script( 'startnext-main', get_template_directory_uri() . '/assets/js/startnext-main.js', array( 'jquery','masonry' ), false, true );
            endif;
        endif;
    else:
        if( $is_minify == true ):
            wp_enqueue_script( 'startnext-main', get_template_directory_uri() . '/assets/js/startnext-main.min.js', array( 'jquery','masonry' ), false, true );
        else :
            wp_enqueue_script( 'startnext-main', get_template_directory_uri() . '/assets/js/startnext-main.js', array( 'jquery','masonry' ), false, true );
        endif;
    endif;
    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'startnext_scripts' );

// Custom template tags for this theme.
require get_template_directory() . '/inc/template-tags.php';

// Functions which enhance the theme by hooking into WordPress.
require get_template_directory() . '/inc/template-functions.php';

// Customizer additions.
require get_template_directory() . '/inc/customizer.php';

// Register Custom Navigation Walker
require_once get_template_directory() . '/inc/bootstrap-navwalker.php';

// ACF
require_once get_template_directory() . '/inc/acf.php';

// TGM
require_once get_template_directory() . '/lib/class-tgm-plugin-activation.php';

// Recommended Plugin
require_once get_template_directory() . '/lib/recommended-plugin.php';

// Custom Style
require_once get_template_directory() . '/inc/custom-style.php';

/**
 * Theme Demos
 */
$pcs = trim( get_option( 'startnext_purchase_code_status' ) );
if ( $pcs == 'valid' ) {
	require get_template_directory() . '/lib/theme-demos.php';
}

// Google Font
if ( ! function_exists( 'poppins_fonts' ) ) :
    function poppins_fonts() 
    {
        wp_enqueue_style( 'poppins-fonts', "//fonts.googleapis.com/css?family=Poppins:400,500,600,700", '', '1.0.0', 'screen' );
    }
    endif;
add_action( 'wp_enqueue_scripts', 'poppins_fonts' );

/**
 * Remove pages from search result
 */
if ( ! function_exists( 'startnext_remove_pages_from_search' ) ) :
    function startnext_remove_pages_from_search() {
		global $wp_post_types;
		$wp_post_types['page']->exclude_from_search = true;
	}
endif;
add_action('init', 'startnext_remove_pages_from_search');

//Excerpt More
if ( ! function_exists( 'startnext_excerpt_more' ) ) :
    function startnext_excerpt_more( $more ) {
        return ' ';
    }
    endif;
    add_filter('excerpt_more', 'startnext_excerpt_more');

   
// Filter the categories archive widget to add a span around post count
function startnext_cat_count_span( $links ) {
    $links = str_replace( '</a> (', '</a><span class="post-count">(', $links );
    $links = str_replace( ')', ')</span>', $links );
    return $links;
}
add_filter( 'wp_list_categories', 'startnext_cat_count_span' );

// Filter the archives widget to add a span around post count
function startnext_archive_count_span( $links ) {
    $links = str_replace( '</a>&nbsp;(', '</a><span class="post-count">(', $links );
    $links = str_replace( ')', ')</span>', $links );
    return $links;
}
add_filter( 'get_archives_link', 'startnext_archive_count_span' );

// If page edited by elementor
if ( ! function_exists( 'startnext_is_elementor' ) ) :
	function startnext_is_elementor(){
		if ( function_exists( 'elementor_load_plugin_textdomain' ) ):
			global $post;
			return \Elementor\Plugin::$instance->db->is_built_with_elementor($post->ID);
		endif;
	}
endif;

// wp_body_open() for Old WordPress Version
if ( ! function_exists( 'wp_body_open' ) ) {
    function wp_body_open() {
        do_action( 'wp_body_open' );
    }
}

/**
 * StarTnext RTL
*/
if( ! function_exists( 'startnext_rtl' ) ):
	function startnext_rtl() {
		global $startnext_opt;

		if(	isset( $startnext_opt['startnext_enable_rtl'])  ):
			$startnext_rtl_opt = $startnext_opt['startnext_enable_rtl'];
		else:
			$startnext_rtl_opt = 'disable';
		endif;

		if ( isset( $_GET['rtl'] ) ) {
			$startnext_rtl_opt = $_GET['rtl'];
		}

		if ( $startnext_rtl_opt == 'enable' ) :
			$startnext_rtl = true;
		else:
			$startnext_rtl = false;
		endif;
		
		return $startnext_rtl;
	}
endif;


/**
 * Classes
 */
require get_template_directory() . '/inc/classes/StartNext_base.php';
require get_template_directory() . '/inc/classes/StartNext_rt.php';
require get_template_directory() . '/inc/classes/StartNext_admin_page.php';
require get_template_directory() . '/inc/admin/dashboard/StartNext_admin_dashboard.php';

/**
 * Admin dashboard style and scripts
 */
add_action( 'admin_enqueue_scripts', function() {
    global $pagenow;
    wp_enqueue_script( 'startnext-admin', get_template_directory_uri() .'/assets/js/startnext-admin.js', array('jquery'), '1.0.0', true );
    if ( $pagenow == 'admin.php' ) {
        wp_enqueue_style( 'startnext-admin-dashboard', get_template_directory_uri() .'/assets/css/admin-dashboard.min.css' );
    }
});

/**
 * Redirect after theme activation
 */
add_action( 'after_switch_theme', function() {
    if ( isset( $_GET['activated'] ) ) {
        wp_safe_redirect( admin_url('admin.php?page=startnext') );
		update_option( 'startnext_purchase_code_status', '', 'yes' );
		update_option( 'startnext_purchase_code', '', 'yes' );
        exit;
	}
	update_option('notice_dismissed', '0');
});

/**
 * Notice dismiss handle
 */
add_action( 'admin_init', function() {
    if ( isset($_GET['dismissed']) && $_GET['dismissed'] == 1 ) {
        update_option('notice_dismissed', '1');
    }
});

$pcs = trim( get_option( 'startnext_purchase_code_status' ) );
if ( $pcs != 'valid' ) {
    function startnext_deregister(){
        wp_deregister_script( 'startnext-main' );
        wp_deregister_style( 'startnext-style-main' );
    }
    add_action( 'wp_enqueue_scripts', 'startnext_deregister' );
}else{
    // Load WooCommerce compatibility file.
    if ( class_exists( 'WooCommerce' ) ) {
        require get_template_directory() . '/inc/woocommerce.php';
    }
}


/**
 * Inc
 */
include_once get_template_directory() . '/inc/init.php';