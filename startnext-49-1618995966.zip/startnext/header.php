<!doctype html><?php global $startnext_opt; ?>
<?php
// Option Data
if( isset( $startnext_opt['header_script'] ) ):
    $main_logo              = $startnext_opt['main_logo']['url'];
    $mobile_logo            = $startnext_opt['mobile_logo']['url'];
    $header_script          = $startnext_opt['header_script'];
    $header_button          = $startnext_opt['header_button'];
    $header_button_link     = $startnext_opt['header_button_link'];
    $enable_cart            = $startnext_opt['enable_cart'];
    $enable_box_layout      = $startnext_opt['enable_box_layout'];
    $enable_nav_full_width  = $startnext_opt['enable_nav_full_width'];
    $nav_item_align_opt     = $startnext_opt['nav_item_align'];    
    $navbar_class_opt       = $startnext_opt['navbar_class'];    
    $enable_white_color_logo= $startnext_opt['enable_white_color_logo'];    
    $nav_bg_white           = $startnext_opt['nav_background_color_white'];    
else:
    $main_logo              = '';
    $mobile_logo            = '';
    $header_script          = '';
    $header_button          = '';
    $header_button_link     = '';
    $nav_bg_white           = false;    
    $enable_nav_full_width  = false;
    $enable_cart            = false;
    $enable_box_layout      = false;
    $enable_white_color_logo= false; 
    $nav_item_align_opt     = 'right';    
    $navbar_class_opt       = '';   
endif;

// Box layout
if ( $enable_box_layout == true ):
    $boxed_layout = 'boxed-layout';
else:
    $boxed_layout = '';
endif;

if( startnext_rtl() == true ): ?><html dir="rtl" <?php language_attributes(); ?>>
<?php else: ?><html <?php language_attributes(); ?>><?php endif; ?>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <?php 
    wp_head();

    // Google Analytic Code ?>
    <script><?php echo $header_script; ?></script>

</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <div class="default-layout <?php echo esc_attr( $boxed_layout ); ?>">
        <?php startnext_preloader(); ?><!-- End Preloader Area -->

        <?php
        $header_style = '';
        global $startnext_opt;
            if ( !empty($startnext_opt['header_style']) && ($startnext_opt['header_style'] != '' ) ):
                $header_style 			= new WP_Query(array(
                    'post_type' 		=> 'header',
                    'posts_per_page' 	=> -1,
                    'p' 				=> $startnext_opt['header_style'],
                ));
            endif;

            if ( !empty($header_style) ):
                if ( $header_style->have_posts() ):
                    while ( $header_style->have_posts() ) : $header_style->the_post();
                        the_content();
                    endwhile;
                    wp_reset_postdata();
                endif;
            else: 
                // Nav background color white. 
                if( function_exists('acf_add_options_page') ) 
                {
                        $hide_banner        = get_field('nav_background_color_white');
                        $full_width_nav     = get_field('nav_container_fluid');
                        $nav_item_align     = get_field('nav_item_align');

                        // Navbar Width
                        if( $full_width_nav == true ):
                            $container      =   'container-fluid';
                            $style_class    =   'navbar-style-three';
                        else:
                            $container      =   'container';
                            $style_class    =   '';
                        endif;

                        // Nav item left
                        if( $nav_item_align == 'right' ):
                            $menu_class = 'navbar-nav nav ml-auto';
                        elseif( $nav_item_align == 'left' ):
                            $menu_class = 'navbar-nav nav';
                        elseif( $nav_item_align == 'center' ):
                            $menu_class = 'navbar-nav nav mr-auto ml-auto';
                        else:
                            $menu_class = 'navbar-nav nav ml-auto';
                        endif;

                        // Nav Banner hide
                        if(  $hide_banner == true ):
                            $nav_bg_class = 'p-relative';
                        else:
                            $nav_bg_class = '';
                        endif;

                        if( get_field('enable_white_logo') == true ){
                            $main_logo    =     $startnext_opt['white_main_logo']['url'];
                        }
                        
                        if( get_field('enable_white_logo') == '' ){
                            if( is_archive() || is_author() || is_category() || is_home() || is_single() || is_tag() && 'post' == get_post_type() ):
                                if( $enable_white_color_logo == true ):
                                    $main_logo    =     $startnext_opt['white_main_logo']['url'];
                                endif;
                                
                                if( $nav_bg_white == true ):
                                    $nav_bg_class = 'p-relative';
                                endif;

                                if( $enable_nav_full_width == true ):
                                    $container      =   'container-fluid';
                                    $style_class    =   'navbar-style-three';
                                endif;

                                if( $nav_item_align_opt == 'right' ):
                                    $menu_class = 'navbar-nav nav ml-auto';
                                elseif( $nav_item_align_opt == 'left' ):
                                    $menu_class = 'navbar-nav nav';
                                elseif( $nav_item_align_opt == 'center' ):
                                    $menu_class = 'navbar-nav nav mr-auto ml-auto';
                                endif;

                            endif;
                        }

                        $navbar_class = get_field( 'navbar_class' );
                        if( $navbar_class != '' ):
                            $navbar_class = get_field( 'navbar_class' );
                        elseif( $navbar_class_opt != '' ):
                            $navbar_class = $navbar_class_opt;
                        else:
                            $navbar_class = '';
                        endif;
                    } else {
                        $style_class            = '';
                        $nav_bg_class           = '';
                        $nav_container_fluid    = '';
                        $navbar_class           = '';
                        $container              = 'container';
                    }

                    if( isset($startnext_opt['welcome_text']) ):
                        $call_number           = $startnext_opt['call_number'];
                        $call_number_link      = $startnext_opt['call_number_link'];
                        $address               = $startnext_opt['address'];
                        $time                  = $startnext_opt['time'];
                        $welcome_text          = $startnext_opt['welcome_text'];
                    else:
                        $call_number           = '';
                        $call_number_link      = '';
                        $address               = '';
                        $welcome_text          = '';
                        $time                  = '';
                    endif;
                    ?>
                
                    <header id="header" class="headroom <?php echo esc_attr( $style_class ); ?> <?php if ( is_user_logged_in() ) {echo esc_attr('hide-adminbar');} ?> <?php echo $navbar_class; ?>"> <!-- Start Navbar Area -->


                        <!-- Start Top Header Area -->
                        <?php if( isset( $startnext_opt['hide_top_header'] ) && $startnext_opt['hide_top_header'] != 1 ){
                            if( $time != '' ) { ?>
                                <div class="top-header">
                                    <div class="container">
                                        <div class="row align-items-center">
                                            <div class="col-lg-3">
                                                <div class="header-left-content">
                                                    <p><?php echo esc_html($welcome_text); ?></p>
                                                </div>
                                            </div>
                                            <div class="col-lg-9">
                                                <div class="header-right-content">
                                                    <ul>
                                                        <li>
                                                            <a href="<?php echo esc_url( $call_number_link ); ?>">
                                                                <i class='fa fa-phone'></i>
                                                                <?php echo esc_html( $call_number ); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <i class='fa fa-envelope-o'></i>
                                                            <?php echo esc_html( $address ); ?>
                                                        </li>
                                                        <li>
                                                            <i class='fa fa-clock-o'></i>
                                                            <?php echo esc_html( $time ); ?>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <?php
                            }  
                        } ?>
                        <!-- End Top Header Area -->

                        <div class="startp-mobile-nav float-menu-d-none">
                            <div class="logo">
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" >
                                    <?php
                                    if (!$mobile_logo == ''){ ?>
                                        <img src="<?php echo esc_url( $mobile_logo, 'startnext' ); ?>" alt="<?php bloginfo('name'); ?>">
                                    <?php }elseif(!$main_logo =='') { ?>
                                        <img src="<?php echo esc_url( $main_logo, 'startnext' ); ?>" alt="<?php bloginfo('name'); ?>">
                                    <?php } else {
                                        bloginfo('name');
                                    } ?>
                                </a>
                            </div>

                            <div class="float-burger-menu" data-toggle="modal" data-target="#FloatMenu"><!-- Float burger menu -->
                                <span class="top-bar"></span>
                                <span class="middle-bar"></span>
                                <span class="bottom-bar"></span>
                            </div>
                            
                            <?php if ( class_exists( 'WooCommerce' ) ):  ?><!-- Cart link for mobile device -->
                                <?php if( $enable_cart == true ): ?>
                                    <a href="<?php echo esc_url(wc_get_cart_url()) ?>" class="cart-link">
                                        <i class='bx bx-cart-alt'></i>
                                        <span class="mini-cart-count"></span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="startp-nav  <?php echo esc_attr($nav_bg_class, 'startnext')?>">
                            <div class="<?php echo esc_attr( $container ); ?>">
                                <nav class="navbar navbar-expand-md navbar-light">
                                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand">
                                        <?php
                                            if (!$main_logo == ''){ ?>
                                                <img src="<?php echo esc_url( $main_logo ); ?>" alt="<?php bloginfo('name'); ?>">
                                            <?php } else { 
                                                bloginfo('name'); 
                                            } 
                                        ?>
                                    </a>
                                    <?php
                                    if(has_nav_menu('main-menu')){
                                        wp_nav_menu( array(
                                            'theme_location'  => 'main-menu',
                                            'depth'	          => 5, 
                                            'container'       => 'div',
                                            'container_class' => 'collapse navbar-collapse mean-menu',
                                            'container_id'    => 'navbarSupportedContent',
                                            'menu_class'      => $menu_class,
                                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                                            'walker'          => new Bootstrap_Navwalker(),
                                        ) );
                                    }
                                    ?>
                                    <?php if ( class_exists( 'WooCommerce' ) ): ?>
                                        <?php if( $enable_cart == true ): ?>
                                            <a href="<?php echo esc_url(wc_get_cart_url()) ?>" class="cart-link">
                                                <i class='bx bx-cart-alt'></i>
                                                <span class="mini-cart-count"></span>
                                            </a> 
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    

                                    <?php if ( !$header_button == '' ): ?>
                                        <div class="others-option">
                                            <a href="<?php echo esc_url($header_button_link); ?>" class="btn btn-primary">
                                                <?php echo esc_html($header_button); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </nav>
                            </div> 
                        </div>
                    </header><!-- End Navbar Area -->

                    <div id="FloatMenu" class="modal fade modal-right float-menu-modal" tabindex="-1" role="dialog"><!-- Float Menu Modal -->
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body p-0">
                                    <div class="startp-mobile-nav startp-float-menu"></div>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php endif; ?>
                    
                <div id="content" class="site-content">