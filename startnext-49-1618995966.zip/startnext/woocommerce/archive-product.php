<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

do_action( 'woocommerce_before_main_content' );

if( function_exists('acf_add_options_page') ) {
	$hide_banner = get_field('page_banner_hide');
}else {
	$hide_banner = false;
}

global $startnext_opt;
if( isset( $startnext_opt['enable_lazyloader'] ) ):
    $is_lazyloader = $startnext_opt['enable_lazyloader'];
else:
    $is_lazyloader = true;
endif;

$is_shape_image     = isset( $startnext_opt['enable_shape_images']) ? $startnext_opt['enable_shape_images'] : '1';
$bg_image           = isset( $startnext_opt['banner_shape_image']['url']) ? $startnext_opt['banner_shape_image']['url'] : '';
$background_image = !empty( $bg_image ) ? "style='background: url( $bg_image );'" : '';

?>
    <?php if( $hide_banner == false ): ?>
        <header class="woocommerce-products-header">
            <div class="page-title-area" <?php echo $background_image; ?>>>
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
                                <h2 class="woocommerce-products-header__title page-title"><?php woocommerce_page_title(); ?></h2>
                                <?php woocommerce_breadcrumb(); ?>
                                <?php if ( function_exists('yoast_breadcrumb') ) {
                                    yoast_breadcrumb( '<p class="startnext-seo-breadcrumbs" id="breadcrumbs">','</p>' );
                                } ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <?php if( $is_shape_image == '1' ): ?>
                    <div class="shape1">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape2 rotateme">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape3">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape4">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape5">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape5.png') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape6 rotateme">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext')?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape7">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape4.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="shape8 rotateme">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg') ?>" alt="<?php echo esc_attr__('shape','startnext'); ?>">
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php do_action( 'woocommerce_archive_description' ); ?>
        </header>
    <?php endif; ?>

    <div class="shop-area ptb-80">
        <div class="container">
            <div class="row">
                <div class="<?php if ( is_active_sidebar( 'shop-sidebar' ) ) { echo esc_attr('col-lg-8 col-md-12');} else{ echo esc_attr('col-lg-12 col-md-12');} ?>">
                    <?php
                    if ( woocommerce_product_loop() ) {

                        /**
                         * Hook: woocommerce_before_shop_loop.
                         *
                         * @hooked woocommerce_output_all_notices - 10
                         * @hooked woocommerce_result_count - 20
                         * @hooked woocommerce_catalog_ordering - 30
                         */

                        ?>
                        <div class="woocommerce-topbar">
                            <?php do_action( 'woocommerce_before_shop_loop' ); ?>
                        </div>
                        <?Php

                        woocommerce_product_loop_start();

                        if ( wc_get_loop_prop( 'total' ) ) {
                            while ( have_posts() ) {
                                the_post();

                                /**
                                 * Hook: woocommerce_shop_loop.
                                 *
                                 * @hooked WC_Structured_Data::generate_product_data() - 10
                                 */
                                do_action( 'woocommerce_shop_loop' );

                                wc_get_template_part( 'content', 'product' );
                            }
                        }

                        woocommerce_product_loop_end();

                        /**
                         * Hook: woocommerce_after_shop_loop.
                         *
                         * @hooked woocommerce_pagination - 10
                         */
                        do_action( 'woocommerce_after_shop_loop' );
                    } else {
                        /**
                         * Hook: woocommerce_no_products_found.
                         *
                         * @hooked wc_no_products_found - 10
                         */
                        do_action( 'woocommerce_no_products_found' );
                    }
                    ?>
                </div>
                <?php
                do_action( 'woocommerce_sidebar' );

                /**
                 * Hook: woocommerce_after_main_content.
                 *
                 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
                 */
                do_action( 'woocommerce_after_main_content' );

                /**
                 * Hook: woocommerce_sidebar.
                 *
                 * @hooked woocommerce_get_sidebar - 10
                 */

                get_footer( 'shop' );

                ?>
            </div>
        </div>
    </div>