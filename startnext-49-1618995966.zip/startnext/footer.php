<?php
/**
 * StartNext footer
 */
    global $startnext_opt;

    if( isset($startnext_opt['blog_title']) ):
        $enable_back_to_top     = $startnext_opt['enable_back_to_top'];
        $main_logo              = $startnext_opt['main_logo']['url'];
        $mobile_logo            = $startnext_opt['mobile_logo']['url'];
        $footer_shape_images    = $startnext_opt['enable_footer_shape_images'];
    else:
        $enable_back_to_top     = true;
        $main_logo              =  '';
        $mobile_logo            =  '';
        $footer_shape_images    =  false;
    endif;

    $footer_column = !empty($startnext_opt['footer_column']) ? $startnext_opt['footer_column'] : '';
?>
        </div><!-- #content -->

        <?php
            $footer_style = '';
            if ( !empty( $startnext_opt['footer_style'] ) ) {
                $footer_style = new WP_Query ( array (
                    'post_type'         => 'footer',
                    'posts_per_page'    => -1,
                    'p'                 => $startnext_opt['footer_style'],
                ));
            }
            if ( !empty( $footer_style ) ):
                if ( $footer_style->have_posts() ):
                    while ( $footer_style->have_posts() ) : $footer_style->the_post();
                        the_content();
                    endwhile;
                    wp_reset_postdata();
                endif;
            else: ?>	
                <footer class="footer-area bg-f7fafd"> <!-- Start Footer Area -->
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-<?php echo esc_attr($footer_column); ?> col-md-<?php echo esc_attr($footer_column); ?>">
                                <div class="single-footer-widget">
                                    <div class="logo">
                                        <a href="<?php echo site_url(); ?>" class="navbar-brand">
                                            <?php
                                            // Site Logo
                                            if (!$main_logo == ''){ ?>
                                                <img src="<?php echo esc_url( $main_logo ); ?>" alt="<?php bloginfo('name'); ?>">
                                            <?php } else { bloginfo('name'); } ?>
                                        </a>
                                    </div>
                                    <?php 
                                        if ( is_active_sidebar( 'footer-one' ) ) { 
                                            dynamic_sidebar('footer-one'); 
                                        } 
                                    ?>
                                </div>
                            </div>

                            <?php 
                                if ( is_active_sidebar( 'footer-two' ) ) { 
                                    dynamic_sidebar('footer-two'); 
                                } 
                            ?>

                            <?php 
                                if ( is_active_sidebar( 'footer-three' ) ) { 
                                    dynamic_sidebar('footer-three'); 
                                } 
                            ?>

                            <div class="col-lg-<?php echo esc_attr($footer_column); ?> col-md-<?php echo esc_attr($footer_column); ?>">
                                <div class="single-footer-widget">
                                    <?php 
                                    if ( is_active_sidebar( 'footer-four' ) ) { 
                                        dynamic_sidebar('footer-four'); 
                                    } 
                                    ?>

                                    <?php get_template_part('inc/social-link', 'social-link'); ?>
                                </div>
                            </div>

                            <?php if(isset($startnext_opt['copyright_text'])): ?>
                                <div class="col-lg-12 col-md-12">
                                    <div class="copyright-area">
                                        <p><?php echo wp_kses_post($startnext_opt['copyright_text']);?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if( $footer_shape_images == true ): ?>
                        <div class="shape1">
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.png');?>" alt="<?php echo esc_attr__('shape', 'startnext') ?>">
                        </div>

                        <div class="shape8 rotateme">
                            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg');?>" alt="<?php echo esc_attr__('shape2', 'startnext') ?>">
                        </div>
                    <?php endif; ?>
                </footer><!-- End Footer Area -->
	        <?php endif; ?>
            
            <?php if ( $enable_back_to_top == true ): ?>
                <div class="go-top"><i data-feather="arrow-up"></i></div>
            <?php endif; ?>

            <?php
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if ( strpos($actual_link, 'themes.envytheme.com/startp') != false ): ?>
                <div class="et-demo-options-toolbar">
                <?php
                    global $wp, $startnext_opt;
                    $current_url = home_url(add_query_arg(array(), $wp->request));
                    ?>
                    <?php if( startnext_rtl() == true ): ?>
                        <a href="<?php echo esc_url( $current_url ); ?>" class="hint--bounce hint--left hint--black" id="toggle-quick-options" aria-label="LTR Demo">
                            <i class="bx bx-left-indent"></i>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo esc_url( $current_url ); ?>/?rtl=enable" class="hint--bounce hint--left hint--black" id="toggle-quick-options" aria-label="RTL Demo">
                            <i class="bx bx-right-indent"></i>
                        </a>
                    <?php endif; ?>
                    <a href="mailto:hello@envytheme.com" target="_blank" rel="nofollow" class="hint--bounce hint--left hint--black" aria-label="Reach Us">
                        <i class="bx bx-support"></i>
                    </a>
                    <a href="https://docs.envytheme.com/docs/startnext-theme-documentation/" target="_blank" rel="nofollow" class="hint--bounce hint--left hint--black" aria-label="Documentation">
                        <i class="bx bx-book"></i>
                    </a>
                    <a href="https://1.envato.market/yKPPy" target="_blank" rel="nofollow" class="hint--bounce hint--left hint--black" aria-label="Purchase StartNext">
                        <i class="bx bx-cart-alt bx-flashing"></i>
                    </a>
                </div>
            <?php endif; ?>

            <?php wp_footer(); ?>
        </div>
    </body>
</html>