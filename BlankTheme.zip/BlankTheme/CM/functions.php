<?php
// Add all js files
function wptuts_scripts_with_jquery() {
    // wp_enqueue_script( 'jqurey-library', get_template_directory_uri() . '/js/jquery.min.js', array( 'jquery' ), true,true);
    // wp_enqueue_script( 'pooper-min', get_template_directory_uri() . '/js/popper.min.js', array( 'jquery' ), true,true);
    // wp_enqueue_script( 'bootstrap-min', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), true,true);
    // wp_enqueue_script( 'owl-min', get_template_directory_uri() . '/js/owl.carousel.min.js', array( 'jquery' ), true,true);
    wp_enqueue_script( 'custom', get_template_directory_uri() . '/js/custom.js', array( 'jquery' ), true,true);
}
add_action( 'wp_enqueue_scripts', 'wptuts_scripts_with_jquery' );

/*
 * Let WordPress manage the document title.
 * By adding theme support, we declare that this theme does not use a
 * hard-coded <title> tag in the document head, and expect WordPress to
 * provide it for us.
 */
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );

// This theme uses wp_nav_menu() in two locations.
register_nav_menus( array(
	'header_menu'    => __( 'Header Menu', 'internationalteams' )
) );


if ( !function_exists( 'of_get_option' ) ) {
	function of_get_option($name, $default = false) {
		
		$optionsframework_settings = get_option('optionsframework');
		
		// Gets the unique option id
		$option_name = $optionsframework_settings['id'];
		
		if ( get_option($option_name) ) {
			$options = get_option($option_name);
		}
			
		if ( isset($options[$name]) ) {
			return $options[$name];
		} else {
			return $default;
		}
	}
}

function cm_widgets_init() {

	register_sidebar( array(
		'name'          => __( 'Sidebar', 'cm' ),
		'id'            => 'side-bar',
		'description'   => __( 'Appears in the Sidebar section of the site.', 'cm' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'cm_widgets_init' );

add_filter( 'gform_field_css_class', 'custom_class', 10, 3 );
function custom_class( $classes, $field, $form ) {
    if ( $field->type != 'submit' ) {
        $field->size .= ' form-control';
    }
    return $classes;
}

add_filter( 'gform_enable_field_label_visibility_settings', '__return_true' );

// add_filter( 'gform_submit_button', 'form_submit_button', 10, 2 );
// function form_submit_button($button, $form) {
//     return '<input type="submit" class="button BtnGreenLink" id="gform_submit_button_' . $form['id'] . '" value="' . $form['button']['text'] . '">';
// }



?>