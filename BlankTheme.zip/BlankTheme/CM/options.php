<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 *
 */

function optionsframework_option_name() {

	// This gets the theme name from the stylesheet (lowercase and without spaces)
	$themename = get_option( 'stylesheet' );
	$themename = preg_replace("/\W/", "_", strtolower($themename) );

	$optionsframework_settings = get_option('optionsframework');
	$optionsframework_settings['id'] = $themename;
	update_option('optionsframework', $optionsframework_settings);

	// echo $themename;
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 */

function optionsframework_options() {

	// Test data
	$test_array = array(
		'one' => __('One', 'options_check'),
		'two' => __('Two', 'options_check'),
		'three' => __('Three', 'options_check'),
		'four' => __('Four', 'options_check'),
		'five' => __('Five', 'options_check')
	);

	// Multicheck Array
	$multicheck_array = array(
		'one' => __('French Toast', 'options_check'),
		'two' => __('Pancake', 'options_check'),
		'three' => __('Omelette', 'options_check'),
		'four' => __('Crepe', 'options_check'),
		'five' => __('Waffle', 'options_check')
	);

	// Multicheck Defaults
	$multicheck_defaults = array(
		'one' => '1',
		'five' => '1'
	);

	// Background Defaults
	$background_defaults = array(
		'color' => '',
		'image' => '',
		'repeat' => 'repeat',
		'position' => 'top center',
		'attachment'=>'scroll' );

	// Typography Defaults
	$typography_defaults = array(
		'size' => '15px',
		'face' => 'georgia',
		'style' => 'bold',
		'color' => '#bada55' );

	// Typography Options
	$typography_options = array(
		'sizes' => array( '12','14','16','20' ),
		'faces' => array( 'Helvetica Neue' => 'Helvetica Neue', 'georgia' => 'Georgia' ),
		'styles' => array( 'normal' => 'Normal','bold' => 'Bold' ),
		'color' => false
	);

	// Pull all the categories into an array
	$options_categories = array();
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	// Pull all tags into an array
	$options_tags = array();
	$options_tags_obj = get_tags();
	foreach ( $options_tags_obj as $tag ) {
		$options_tags[$tag->term_id] = $tag->name;
	}

	// Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	$options_pages[''] = 'Select a page:';
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}

	// If using image radio buttons, define a directory path
	$imagepath =  get_template_directory_uri() . '/img/';
	$defaultLogo = $imagepath.'logo.png';
	$footer_logo = 	$imagepath.'logo_footer.png';

	$options = array();

	$options[] = array(
		'name' => __('Basic Settings', 'options_check'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('Main Header Logo', 'options_check'),
		'desc' => __('Upload logo here.', 'options_check'),
		'id' => 'main_logo',
		'std' => $defaultLogo,
		'type' => 'upload');

	$options[] = array(
		'name' => __('Footer Logo', 'options_check'),
		'desc' => __('Upload Footer Logo.', 'options_check'),
		'id' => 'footer_logo',
		'std' => $footer_logo,
		'type' => 'upload');

	$options[] = array(
		'name' => __('Contact Info', 'options_check'),
		'type' => 'heading');

	$email_address = 'connect@iteams.org.au';

	$options[] = array(
		'name' => __('Show Email in footer?', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'email_address_check',
		'std' => '',
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('Add Email Address', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'email_address',
		'std' => $email_address,
		'type' => 'text');	

	$options[] = array(
		'name' => __('Show Phone Number in footer?', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'phone_number_check',
		'std' => '',
		'type' => 'checkbox');

	$phone_number = '(02) 9890 2244';
	$options[] = array(
		'name' => __('Add Phone Number', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'phone_number',
		'std' => $phone_number,
		'type' => 'text');	

	$options[] = array(
		'name' => __('Show Fax Number in footer?', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'mobile_number_check',
		'std' => '',
		'type' => 'checkbox');

	$mobile_number = '(02) 9890 2244';
	$options[] = array(
		'name' => __('Fax Number', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'mobile_number',
		'std' => $mobile_number,
		'type' => 'text');

	$options[] = array(
		'name' => __('Show Postal Address in footer?', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'address_1_check',
		'std' => '',
		'type' => 'checkbox');

	$address_1 = 'PO Box 1123 
Baulkham Hills, NSW 1755
AUSTRALIA';
	$options[] = array(
		'name' => __('Postal Address', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'address_1',
		'std' => $address_1,
		'type' => 'textarea');	

	$options[] = array(
		'name' => __('Show Physical Address in footer?', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'address_2_check',
		'std' => '',
		'type' => 'checkbox');

	$address_2 = '27 Iron Street
North Parramatta, NSW';
	$options[] = array(
		'name' => __('Physical Address', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'address_2',
		'std' => $address_2,
		'type' => 'textarea');

	$options[] = array(
		'name' => __('Show Additional Contact Information in footer?', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'address_3_check',
		'std' => '',
		'type' => 'checkbox');

	$address_3 = 'Please direct all mail to Po Box.<br>
<b>ABN:</b> 36 138 471 706<br>
Charitable Fundraising Number: 18557';

	$options[] = array(
		'name' => __('Additional Contact Information', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'address_3',
		'std' => $address_3,
		'type' => 'textarea');

	$options[] = array(
		'name' => __('Social Media', 'options_check'),
		'type' => 'heading');

	$social_fb = 'https://www.facebook.com';
	$social_tw = 'https://www.twitter.com';
	$social_ins = 'https://www.instagram.com';
	$social_you = 'https://www.youtube.com';
	$social_vimeo = 'https://www.vimeo.com';

	$options[] = array(
		'name' => __('Facebook', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'social_fb',
		'std' => $social_fb,
		'type' => 'text');

	$options[] = array(
		'name' => __('Twitter', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'social_tw',
		'std' => $social_tw,
		'type' => 'text');

	$options[] = array(
		'name' => __('Instagram', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'social_ins',
		'std' => $social_ins,
		'type' => 'text');

	$options[] = array(
		'name' => __('youTube', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'social_you',
		'std' => $social_you,
		'type' => 'text');

	$options[] = array(
		'name' => __('Vimeo', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'social_vimeo',
		'std' => $social_vimeo,
		'type' => 'text');	

	$options[] = array(
		'name' => __('Sign Up', 'options_check'),
		'type' => 'heading');

	$form_title = 'Get our emails';
	$options[] = array(
		'name' => __('Title', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'form_title',
		'std' => $form_title,
		'type' => 'text');	

	$form_content = '';
	$options[] = array(
		'name' => __('Content', 'options_check'),
		'desc' => __('', 'options_check'),
		'id' => 'form_content',
		'std' => $form_content,
		'type' => 'textarea');

	return $options;
}
?>